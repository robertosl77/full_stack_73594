import HomePage from "../home-page"

export default function Page() {
  return <HomePage />
}
