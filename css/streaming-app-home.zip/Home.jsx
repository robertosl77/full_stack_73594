"use client"

import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import "./styles/main.css"

// Obtener API key desde variables de entorno
const API_KEY = process.env.REACT_APP_OMDB_API_KEY
const TERM_LIST = ["star", "man", "love", "war", "life"]

function Home() {
  const [pelis, setPelis] = useState([])
  const [currentSlide, setCurrentSlide] = useState(0)
  const navigate = useNavigate()

  useEffect(() => {
    // Verificar que la API key existe
    if (!API_KEY) {
      console.error("API Key no encontrada. Asegúrate de tener REACT_APP_OMDB_API_KEY en tu archivo .env")
      return
    }

    Promise.all(
      TERM_LIST.map((term) =>
        fetch(`https://www.omdbapi.com/?apikey=${API_KEY}&s=${term}&type=movie`)
          .then((res) => res.json())
          .then((data) => {
            const valids = data.Search?.filter((p) => p.Poster !== "N/A") || []
            return valids.length ? valids[Math.floor(Math.random() * valids.length)] : null
          }),
      ),
    ).then((resultados) => {
      setPelis(resultados.filter(Boolean).slice(0, 5))
    })

    // Auto-slide
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % 5)
    }, 4000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="hero-container">
      {/* Background */}
      <div className="hero-bg">
        {pelis.length > 0 && (
          <img src={pelis[currentSlide]?.Poster || "/placeholder.svg?height=600&width=400"} alt="" />
        )}
      </div>

      {/* Main Content */}
      <div className="hero-content">
        <div className="main-content">
          <div className="content-grid">
            {/* Left Content */}
            <div className="left-content">
              <div className="premium-badge">
                <svg className="icon-md" viewBox="0 0 24 24">
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                </svg>
                Películas Premium
              </div>

              <h1 className="title-hero">
                <span className="title-line-primary">STREAMING</span>
                <span className="title-line-gradient">EXPERIENCE</span>
              </h1>

              <p className="subtitle-hero">
                Descubre un universo cinematográfico sin límites. Miles de películas, géneros únicos y experiencias
                que transformarán tu manera de ver cine.
              </p>

              <div className="buttons-container">
                <button className="btn-primary" onClick={() => navigate("/catalogo")}>
                  <svg className="btn-icon" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                  Explorar Ahora
                </button>

                <button className="btn-secondary">
                  Ver Trailer
                  <svg className="btn-icon-small" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M5 12h14M12 5l7 7-7 7" />
                  </svg>
                </button>
              </div>

              <div className="stats-container">
                <div className="stat-item">
                  <div className="stat-number">10K+</div>
                  <div className="stat-label">Películas</div>
                </div>
                <div className="stat-item">
                  <div className="stat-number">50+</div>
                  <div className="stat-label">Géneros</div>
                </div>
                <div className="stat-item">
                  <div className="stat-number">4K</div>
                  <div className="stat-label">Calidad</div>
                </div>
              </div>
            </div>

            {/* Right Content */}
            <div className="right-content">
              {pelis.length > 0 && (
                <div>
                  <div className="featured-movie" onClick={() => navigate(`/pelicula/${pelis[currentSlide].imdbID}`)}>
                    <div className="movie-container">
                      <img
                        src={pelis[currentSlide].Poster || "/placeholder.svg"}
                        alt={pelis[currentSlide].Title}
                        className="movie-poster"
                        style={{ height: '35rem' }}
                      />
                      <div className="movie-overlay" />

                      <div className="movie-info">
                        <h3 className="title-card">{pelis[currentSlide].Title}</h3>
                        <div className="movie-details">
                          <svg className="calendar-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                            <line x1="16" y1="2" x2="16" y2="6" />
                            <line x1="8" y1="2" x2="8" y2="6" />
                            <line x1="3" y1="10" x2="21" y2="10" />
                          </svg>
                          <span>{pelis[currentSlide].Year}</span>
                          <svg className="star-icon-small" viewBox="0 0 24 24">
                            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                          </svg>
                          <span>8.5</span>
                        </div>
                      </div>

                      <div className="play-overlay">
                        <div className="play-button">
                          <svg className="btn-icon-large" viewBox="0 0 24 24">
                            <path d="M8 5v14l11-7z" />
                          </svg>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="thumbnails-container">
                    {pelis.slice(0, 4).map((peli, index) => (
                      <button
                        key={peli.imdbID}
                        onClick={(e) => {
                          e.stopPropagation()
                          setCurrentSlide(index)
                        }}
                        onDoubleClick={() => navigate(`/pelicula/${peli.imdbID}`)}
                        className={`btn-thumbnail ${index === currentSlide ? "active" : ""}`}
                        title="Doble clic para ver detalles"
                      >
                        <img src={peli.Poster || "/placeholder.svg"} alt={peli.Title} style={{ width: '100%', height: '100%', objectFit: 'contain', background: '#111' }} />
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="footer-section">
          <div className="footer-content">
            <div className="developer-info">
              <div className="label-developer">Desarrollado por</div>
              <div className="name-developer">Roberto Sanchez Leiva</div>
              <div className="role-developer">Full Stack Developer • Actividad 13</div>
            </div>

            <div className="social-links">
              <a href="https://www.instagram.com/robertosl77" className="social-link instagram">
                <svg className="social-icon" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-\
