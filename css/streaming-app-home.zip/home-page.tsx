"use client"

import { useEffect, useState } from "react"
import { Play, Star, Calendar, ArrowRight, Instagram, Facebook, Mail, Github } from "lucide-react"
import { Button } from "@/components/ui/button"

const API_KEY = "29d19341"
const TERM_LIST = ["star", "man", "love", "war", "life"]

interface Movie {
  imdbID: string
  Title: string
  Year: string
  Poster: string
}

export default function HomePage() {
  const [movies, setMovies] = useState<Movie[]>([])
  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    Promise.all(
      TERM_LIST.map((term) =>
        fetch(`https://www.omdbapi.com/?apikey=${API_KEY}&s=${term}&type=movie`)
          .then((res) => res.json())
          .then((data) => {
            const valids = data.Search?.filter((p: any) => p.Poster !== "N/A") || []
            return valids.length ? valids[Math.floor(Math.random() * valids.length)] : null
          }),
      ),
    ).then((results) => {
      setMovies(results.filter(Boolean).slice(0, 5))
    })

    // Auto-slide
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % 5)
    }, 4000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden relative">
      {/* Background with movie posters */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent z-10" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/50 z-10" />
        {movies.length > 0 && (
          <img
            src={movies[currentSlide]?.Poster || "/placeholder.svg"}
            alt=""
            className="w-full h-full object-cover opacity-30 transition-all duration-1000"
          />
        )}
      </div>

      {/* Main Content */}
      <div className="relative z-20 min-h-screen flex flex-col">
        {/* Hero Section */}
        <div className="flex-1 flex items-center">
          <div className="max-w-7xl mx-auto px-6 w-full">
            <div className="grid lg:grid-cols-12 gap-8 items-center">
              {/* Left Content */}
              <div className="lg:col-span-7 space-y-8">
                <div className="space-y-6">
                  <div className="inline-flex items-center gap-2 bg-red-600/20 border border-red-500/30 rounded-full px-4 py-2 text-red-400 text-sm font-medium">
                    <Star className="w-4 h-4 fill-current" />
                    Películas Premium
                  </div>

                  <h1 className="text-5xl lg:text-7xl font-black leading-tight">
                    <span className="block text-white">STREAMING</span>
                    <span className="block bg-gradient-to-r from-red-500 via-pink-500 to-purple-500 bg-clip-text text-transparent">
                      EXPERIENCE
                    </span>
                  </h1>

                  <p className="text-xl text-gray-300 leading-relaxed max-w-2xl">
                    Descubre un universo cinematográfico sin límites. Miles de películas, géneros únicos y experiencias
                    que transformarán tu manera de ver cine.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <Button
                    size="lg"
                    className="bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700 text-white px-8 py-4 rounded-xl text-lg font-semibold shadow-2xl hover:shadow-red-500/25 transition-all duration-300 transform hover:scale-105"
                  >
                    <Play className="w-6 h-6 mr-3 fill-current" />
                    Explorar Ahora
                  </Button>

                  <Button
                    variant="outline"
                    size="lg"
                    className="border-2 border-white/20 text-white hover:bg-white/10 px-8 py-4 rounded-xl text-lg font-semibold backdrop-blur-sm bg-transparent"
                  >
                    Ver Trailer
                    <ArrowRight className="w-5 h-5 ml-3" />
                  </Button>
                </div>

                {/* Stats */}
                <div className="flex gap-8 pt-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-white">10K+</div>
                    <div className="text-sm text-gray-400">Películas</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-white">50+</div>
                    <div className="text-sm text-gray-400">Géneros</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-white">4K</div>
                    <div className="text-sm text-gray-400">Calidad</div>
                  </div>
                </div>
              </div>

              {/* Right Content - Featured Movies */}
              <div className="lg:col-span-5">
                {movies.length > 0 && (
                  <div className="relative">
                    {/* Main Featured Movie */}
                    <div className="relative group cursor-pointer">
                      <div className="relative overflow-hidden rounded-2xl shadow-2xl">
                        <img
                          src={movies[currentSlide]?.Poster || "/placeholder.svg"}
                          alt={movies[currentSlide]?.Title}
                          className="w-full h-96 object-cover transition-transform duration-700 group-hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

                        {/* Movie Info */}
                        <div className="absolute bottom-0 left-0 right-0 p-6">
                          <div className="space-y-2">
                            <h3 className="text-2xl font-bold text-white line-clamp-2">
                              {movies[currentSlide]?.Title}
                            </h3>
                            <div className="flex items-center gap-3 text-gray-300">
                              <Calendar className="w-4 h-4" />
                              <span>{movies[currentSlide]?.Year}</span>
                              <div className="flex items-center gap-1">
                                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                                <span>8.5</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Play Button Overlay */}
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <div className="bg-white/20 backdrop-blur-sm rounded-full p-4">
                            <Play className="w-8 h-8 text-white fill-current" />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Movie Thumbnails */}
                    <div className="flex gap-3 mt-4 overflow-hidden">
                      {movies.slice(0, 4).map((movie, index) => (
                        <button
                          key={movie.imdbID}
                          onClick={() => setCurrentSlide(index)}
                          className={`relative flex-shrink-0 w-16 h-20 rounded-lg overflow-hidden transition-all duration-300 ${
                            index === currentSlide ? "ring-2 ring-red-500 scale-110" : "opacity-60 hover:opacity-100"
                          }`}
                        >
                          <img
                            src={movie.Poster || "/placeholder.svg"}
                            alt={movie.Title}
                            className="w-full h-full object-cover"
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-white/10 bg-black/50 backdrop-blur-sm">
          <div className="max-w-7xl mx-auto px-6 py-6">
            <div className="flex flex-col lg:flex-row justify-between items-center gap-6">
              {/* Developer Info */}
              <div className="text-center lg:text-left">
                <div className="text-sm text-gray-400 mb-2">Desarrollado por</div>
                <div className="text-lg font-semibold text-white">Roberto Sanchez Leiva</div>
                <div className="text-sm text-gray-400">Full Stack Developer • Actividad 13</div>
              </div>

              {/* Social Links */}
              <div className="flex gap-4">
                <a
                  href="https://instagram.com/robertosanchezleiva"
                  className="p-3 bg-white/10 hover:bg-pink-500/20 rounded-full transition-colors duration-300 group"
                >
                  <Instagram className="w-5 h-5 text-gray-400 group-hover:text-pink-400" />
                </a>
                <a
                  href="https://facebook.com/robertosanchezleiva"
                  className="p-3 bg-white/10 hover:bg-blue-500/20 rounded-full transition-colors duration-300 group"
                >
                  <Facebook className="w-5 h-5 text-gray-400 group-hover:text-blue-400" />
                </a>
                <a
                  href="mailto:roberto@email.com"
                  className="p-3 bg-white/10 hover:bg-red-500/20 rounded-full transition-colors duration-300 group"
                >
                  <Mail className="w-5 h-5 text-gray-400 group-hover:text-red-400" />
                </a>
                <a
                  href="https://github.com/robertosanchezleiva"
                  className="p-3 bg-white/10 hover:bg-gray-500/20 rounded-full transition-colors duration-300 group"
                >
                  <Github className="w-5 h-5 text-gray-400 group-hover:text-gray-300" />
                </a>
              </div>

              {/* Copyright */}
              <div className="text-xs text-gray-500">© {new Date().getFullYear()} Todos los derechos reservados</div>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Elements */}
      <div className="absolute top-20 right-20 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
      <div className="absolute top-40 right-40 w-1 h-1 bg-pink-500 rounded-full animate-pulse delay-1000" />
      <div className="absolute bottom-40 left-20 w-1.5 h-1.5 bg-purple-500 rounded-full animate-pulse delay-500" />
    </div>
  )
}
